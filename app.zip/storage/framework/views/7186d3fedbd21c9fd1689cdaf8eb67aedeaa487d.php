<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
  <head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Newton's Method Solver</title>

    <!-- Fonts -->

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet" type="text/css">
  </head>
  <body>
    <div id="root"></div>

    <script src="<?php echo e(asset('js/app.js')); ?>" ></script>
  </body>
</html>
<?php /**PATH D:\FILLYCODER\PROJECTS\newtonsmethodsolver\resources\views/welcome.blade.php ENDPATH**/ ?>